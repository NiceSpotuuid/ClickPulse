using System.Globalization;
using System.Runtime.InteropServices;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Interop;
using System.Windows.Media;
using System.Windows.Threading;

namespace ClickPulse;

public partial class MainWindow : Window
{
    private const int HotkeyId = 4101;
    private readonly DispatcherTimer _clickTimer;
    private readonly Random _random = new();
    private readonly StatusToastWindow _statusToast;
    private bool _showStatusNotification = true;

    private IntPtr _windowHandle;
    private HwndSource? _source;
    private bool _hotkeyRegistered;
    private bool _isRunning;
    private bool _isPickingPosition;
    private bool _fixedPosition;
    private int _fixedX;
    private int _fixedY;
    private int _mouseButton;
    private bool _doubleClick;
    private bool _limitedRepeats;
    private long _repeatTarget;
    private long _completedRepeats;
    private long _totalClicks;
    private long _baseIntervalMs;
    private int _randomOffsetMs;
    private NativeMethods.LowLevelMouseProc? _mouseHookProc;
    private IntPtr _mouseHookHandle;

    public MainWindow()
    {
        InitializeComponent();

        _statusToast = new StatusToastWindow();
        _showStatusNotification = AppPreferences.Load().ShowStatusNotification;
        StatusNotificationCheckBox.IsChecked = _showStatusNotification;
        StatusNotificationCheckBox.Checked += StatusNotificationCheckBox_Changed;
        StatusNotificationCheckBox.Unchecked += StatusNotificationCheckBox_Changed;

        _clickTimer = new DispatcherTimer(DispatcherPriority.Background)
        {
            Interval = TimeSpan.FromMilliseconds(100)
        };
        _clickTimer.Tick += ClickTimer_Tick;

        RandomOffsetCheckBox.Checked += RandomOffsetCheckBox_Changed;
        RandomOffsetCheckBox.Unchecked += RandomOffsetCheckBox_Changed;
        SourceInitialized += Window_SourceInitialized;
    }

    private void Window_Loaded(object sender, RoutedEventArgs e)
    {
        UpdatePositionControls();
        UpdateRepeatControls();
        UpdateTimingPreview();
        SetIdleStatus("Bereit");
    }

    private void Window_SourceInitialized(object? sender, EventArgs e)
    {
        _windowHandle = new WindowInteropHelper(this).Handle;
        _source = HwndSource.FromHwnd(_windowHandle);
        _source?.AddHook(WindowProcedure);
        _hotkeyRegistered = NativeMethods.RegisterHotKey(_windowHandle, HotkeyId, NativeMethods.ModNoRepeat, NativeMethods.VkF6);

        if (!_hotkeyRegistered)
        {
            PositionHintText.Text = "F6 ist bereits belegt. Verwende zum Starten und Stoppen die Schaltfläche.";
        }
    }

    private IntPtr WindowProcedure(IntPtr hwnd, int message, IntPtr wParam, IntPtr lParam, ref bool handled)
    {
        if (message == NativeMethods.WmHotkey && wParam.ToInt32() == HotkeyId)
        {
            ToggleClicking();
            handled = true;
        }
        return IntPtr.Zero;
    }

    private void Window_Closed(object? sender, EventArgs e)
    {
        StopClicking(false);
        StopPickingPosition();
        _statusToast.CloseImmediately();

        if (_hotkeyRegistered && _windowHandle != IntPtr.Zero)
        {
            NativeMethods.UnregisterHotKey(_windowHandle, HotkeyId);
        }

        _source?.RemoveHook(WindowProcedure);
    }

    private void Window_PreviewKeyDown(object sender, KeyEventArgs e)
    {
        if (e.Key == Key.Escape)
        {
            if (_isRunning)
            {
                StopClicking();
            }
            if (_isPickingPosition)
            {
                StopPickingPosition();
            }
            e.Handled = true;
        }
    }

    private void StartStopButton_Click(object sender, RoutedEventArgs e) => ToggleClicking();

    private void ToggleClicking()
    {
        if (_isRunning)
        {
            StopClicking();
        }
        else
        {
            StartClicking();
        }
    }

    private void StartClicking()
    {
        if (_isPickingPosition)
        {
            StopPickingPosition();
        }

        if (!TryReadSettings(out string error))
        {
            SetIdleStatus(error);
            return;
        }

        _completedRepeats = 0;
        _isRunning = true;
        _clickTimer.Interval = TimeSpan.FromMilliseconds(GetNextInterval());
        _clickTimer.Start();

        StatusDot.Fill = new SolidColorBrush(Color.FromRgb(76, 220, 159));
        StatusText.Text = "Läuft";
        StartStopButton.Content = "Stoppen (F6)";
        StartStopButton.Background = new SolidColorBrush(Color.FromRgb(196, 61, 48));
        PositionHintText.Text = _fixedPosition
            ? $"Klickziel: X {_fixedX}, Y {_fixedY}."
            : "Die Klicks folgen deiner aktuellen Mausposition.";

        if (_showStatusNotification)
        {
            _statusToast.ShowRunning();
        }
    }

    private bool TryReadSettings(out string error)
    {
        int hours = ReadInt(HoursBox, 0, 999);
        int minutes = ReadInt(MinutesBox, 0, 59);
        int seconds = ReadInt(SecondsBox, 0, 59);
        int milliseconds = ReadInt(MillisecondsBox, 0, 999);

        _baseIntervalMs = hours * 3_600_000L + minutes * 60_000L + seconds * 1_000L + milliseconds;
        // Keep a sensible minimum so the app remains responsive and does not flood the input queue.
        _baseIntervalMs = Math.Clamp(_baseIntervalMs, 10L, 86_400_000L);
        _randomOffsetMs = RandomOffsetCheckBox.IsChecked == true
            ? Math.Clamp(ReadInt(RandomOffsetBox, 0, 5000), 0, 5000)
            : 0;

        _mouseButton = MouseButtonCombo.SelectedIndex;
        _doubleClick = ClickTypeCombo.SelectedIndex == 1;
        _limitedRepeats = RepeatModeCombo.SelectedIndex == 1;
        _repeatTarget = 0;
        if (_limitedRepeats)
        {
            if (!long.TryParse(RepeatCountBox.Text, NumberStyles.Integer, CultureInfo.InvariantCulture, out _repeatTarget)
                || _repeatTarget < 1)
            {
                error = "Bitte gib mindestens eine Wiederholung ein.";
                return false;
            }
            _repeatTarget = Math.Min(_repeatTarget, 99_999_999);
        }

        _fixedPosition = FixedPositionRadio.IsChecked == true;
        _fixedX = ReadInt(PositionXBox, 0, int.MaxValue);
        _fixedY = ReadInt(PositionYBox, 0, int.MaxValue);

        if (_fixedPosition && (!int.TryParse(PositionXBox.Text, out _fixedX) || !int.TryParse(PositionYBox.Text, out _fixedY)))
        {
            error = "Bitte prüfe die X- und Y-Koordinaten.";
            return false;
        }

        error = string.Empty;
        return true;
    }

    private void ClickTimer_Tick(object? sender, EventArgs e)
    {
        if (!_isRunning)
        {
            return;
        }

        if (_fixedPosition && !NativeMethods.SetCursorPos(_fixedX, _fixedY))
        {
            StopClicking();
            SetIdleStatus("Position nicht erreichbar");
            return;
        }

        if (!ClickEngine.SendClick(_mouseButton, _doubleClick))
        {
            StopClicking();
            SetIdleStatus("Klick konnte nicht gesendet werden");
            return;
        }

        _completedRepeats++;
        _totalClicks += _doubleClick ? 2 : 1;
        ClickCountText.Text = _totalClicks.ToString("N0", CultureInfo.GetCultureInfo("de-DE"));

        if (_limitedRepeats && _completedRepeats >= _repeatTarget)
        {
            StopClicking();
            SetIdleStatus("Abgeschlossen");
            return;
        }

        _clickTimer.Interval = TimeSpan.FromMilliseconds(GetNextInterval());
    }

    private double GetNextInterval()
    {
        int offset = _randomOffsetMs > 0 ? _random.Next(-_randomOffsetMs, _randomOffsetMs + 1) : 0;
        return Math.Max(10, _baseIntervalMs + offset);
    }

    private void StopClicking(bool updateStatus = true)
    {
        _clickTimer.Stop();
        _isRunning = false;
        _statusToast.HideAnimated();
        StartStopButton.Content = "Starten (F6)";
        StartStopButton.Background = new SolidColorBrush(Color.FromRgb(0, 120, 212));
        if (updateStatus)
        {
            SetIdleStatus("Bereit");
        }
    }

    private void SetIdleStatus(string message)
    {
        StatusDot.Fill = new SolidColorBrush(Color.FromRgb(132, 148, 174));
        StatusText.Text = message;
    }

    private void StatusNotificationCheckBox_Changed(object sender, RoutedEventArgs e)
    {
        _showStatusNotification = StatusNotificationCheckBox.IsChecked == true;
        AppPreferences.Save(_showStatusNotification);

        if (_showStatusNotification && _isRunning)
        {
            _statusToast.ShowRunning();
        }
        else
        {
            _statusToast.HideAnimated();
        }
    }

    private void TimingField_TextChanged(object sender, TextChangedEventArgs e)
    {
        if (IsLoaded)
        {
            UpdateTimingPreview();
        }
    }

    private void UpdateTimingPreview()
    {
        int hours = ReadInt(HoursBox, 0, 999);
        int minutes = ReadInt(MinutesBox, 0, 59);
        int seconds = ReadInt(SecondsBox, 0, 59);
        int milliseconds = ReadInt(MillisecondsBox, 0, 999);
        long total = hours * 3_600_000L + minutes * 60_000L + seconds * 1_000L + milliseconds;
        total = Math.Clamp(total, 10L, 86_400_000L);

        if (total >= 3_600_000)
        {
            IntervalPreviewText.Text = $"{total / 3_600_000d:0.##} h";
        }
        else if (total >= 60_000)
        {
            IntervalPreviewText.Text = $"{total / 60_000d:0.##} min";
        }
        else if (total >= 1_000)
        {
            IntervalPreviewText.Text = $"{total / 1_000d:0.##} s";
        }
        else
        {
            IntervalPreviewText.Text = $"{total} ms";
        }
    }

    private void RandomOffsetCheckBox_Changed(object sender, RoutedEventArgs e)
    {
        if (RandomOffsetBox is not null)
        {
            RandomOffsetBox.IsEnabled = RandomOffsetCheckBox.IsChecked == true;
        }
    }

    private void RepeatModeCombo_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
        if (RepeatCountBox is not null)
        {
            UpdateRepeatControls();
        }
    }

    private void UpdateRepeatControls()
    {
        RepeatCountBox.IsEnabled = RepeatModeCombo.SelectedIndex == 1;
    }

    private void PositionMode_Checked(object sender, RoutedEventArgs e)
    {
        if (PositionXBox is not null)
        {
            UpdatePositionControls();
        }
    }

    private void UpdatePositionControls()
    {
        bool isFixed = FixedPositionRadio.IsChecked == true;
        PositionXBox.IsEnabled = isFixed;
        PositionYBox.IsEnabled = isFixed;
        PositionHintText.Text = isFixed
            ? "Wähle „Position wählen“, um einen Punkt auf dem Bildschirm festzulegen."
            : "Die Klicks folgen deinem Mauszeiger.";
    }

    private void PickPositionButton_Click(object sender, RoutedEventArgs e)
    {
        if (_isPickingPosition)
        {
            StopPickingPosition();
            return;
        }

        _mouseHookProc = MouseHookCallback;
        _mouseHookHandle = NativeMethods.SetWindowsHookEx(
            NativeMethods.WhMouseLl,
            _mouseHookProc,
            NativeMethods.GetModuleHandle(null),
            0);

        if (_mouseHookHandle == IntPtr.Zero)
        {
            _mouseHookProc = null;
            PositionHintText.Text = "Position konnte nicht erfasst werden. Bitte prüfe die Windows-Berechtigungen.";
            return;
        }

        _isPickingPosition = true;
        PickPositionButton.Content = "Abbrechen";
        PositionHintText.Text = "Klicke jetzt auf die gewünschte Bildschirmposition …";
    }

    private IntPtr MouseHookCallback(int nCode, IntPtr wParam, IntPtr lParam)
    {
        if (nCode >= 0 && wParam.ToInt32() == NativeMethods.WmLButtonDown)
        {
            NativeMethods.MouseLowLevelHookStruct hookData = Marshal.PtrToStructure<NativeMethods.MouseLowLevelHookStruct>(lParam);
            int x = hookData.Point.X;
            int y = hookData.Point.Y;

            Dispatcher.BeginInvoke(new Action(() =>
            {
                PositionXBox.Text = x.ToString(CultureInfo.InvariantCulture);
                PositionYBox.Text = y.ToString(CultureInfo.InvariantCulture);
                FixedPositionRadio.IsChecked = true;
                StopPickingPosition();
                PositionHintText.Text = $"Position gespeichert: X {x}, Y {y}.";
            }));
            return new IntPtr(1);
        }

        return NativeMethods.CallNextHookEx(_mouseHookHandle, nCode, wParam, lParam);
    }

    private void StopPickingPosition()
    {
        if (_mouseHookHandle != IntPtr.Zero)
        {
            NativeMethods.UnhookWindowsHookEx(_mouseHookHandle);
            _mouseHookHandle = IntPtr.Zero;
        }

        _mouseHookProc = null;
        _isPickingPosition = false;
        if (PickPositionButton is not null)
        {
            PickPositionButton.Content = "Position wählen";
        }
    }

    private void NumericTextBox_PreviewTextInput(object sender, TextCompositionEventArgs e)
    {
        e.Handled = e.Text.Any(character => !char.IsDigit(character));
    }

    private static int ReadInt(TextBox textBox, int minimum, int maximum)
    {
        if (!int.TryParse(textBox.Text, NumberStyles.Integer, CultureInfo.InvariantCulture, out int value))
        {
            return minimum;
        }
        return Math.Clamp(value, minimum, maximum);
    }

    private static long ReadLong(TextBox textBox, long minimum, long maximum)
    {
        if (!long.TryParse(textBox.Text, NumberStyles.Integer, CultureInfo.InvariantCulture, out long value))
        {
            return minimum;
        }
        return Math.Clamp(value, minimum, maximum);
    }
}
