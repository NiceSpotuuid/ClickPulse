@echo off
setlocal
cd /d "%~dp0"
where dotnet >nul 2>nul
if errorlevel 1 (
  echo .NET 8 SDK wurde nicht gefunden.
  echo Bitte installiere das .NET 8 SDK und starte diese Datei erneut.
  echo Download: https://dotnet.microsoft.com/download/dotnet/8.0
  pause
  exit /b 1
)

dotnet publish ClickPulse.csproj -c Release -p:PublishProfile=win-x64.pubxml
if errorlevel 1 (
  echo.
  echo Build fehlgeschlagen. Bitte die Fehlermeldung oben pruefen.
  pause
  exit /b 1
)

echo.
echo Fertig! Die EXE liegt in:
echo bin\Release\net8.0-windows\win-x64\publish\ClickPulse.exe
pause
