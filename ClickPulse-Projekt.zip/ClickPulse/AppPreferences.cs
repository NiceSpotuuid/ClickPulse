using System.IO;
using System.Text.Json;

namespace ClickPulse;

internal sealed class AppPreferences
{
    public bool ShowStatusNotification { get; set; } = true;

    private static string SettingsPath => Path.Combine(
        Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData),
        "ClickPulse",
        "settings.json");

    public static AppPreferences Load()
    {
        try
        {
            if (!File.Exists(SettingsPath))
                return new AppPreferences();

            return JsonSerializer.Deserialize<AppPreferences>(File.ReadAllText(SettingsPath))
                   ?? new AppPreferences();
        }
        catch
        {
            return new AppPreferences();
        }
    }

    public static void Save(bool showStatusNotification)
    {
        try
        {
            string? folder = Path.GetDirectoryName(SettingsPath);
            if (!string.IsNullOrWhiteSpace(folder))
                Directory.CreateDirectory(folder);

            string json = JsonSerializer.Serialize(new AppPreferences
            {
                ShowStatusNotification = showStatusNotification
            }, new JsonSerializerOptions { WriteIndented = true });

            File.WriteAllText(SettingsPath, json);
        }
        catch
        {
            // The app remains usable even when preferences cannot be saved.
        }
    }
}
