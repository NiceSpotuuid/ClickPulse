using System.Runtime.InteropServices;

namespace ClickPulse;

internal static class ClickEngine
{
    public static bool SendClick(int mouseButton, bool doubleClick)
    {
        (uint down, uint up) = mouseButton switch
        {
            1 => (NativeMethods.MouseEventRightDown, NativeMethods.MouseEventRightUp),
            2 => (NativeMethods.MouseEventMiddleDown, NativeMethods.MouseEventMiddleUp),
            _ => (NativeMethods.MouseEventLeftDown, NativeMethods.MouseEventLeftUp)
        };

        int clickPairs = doubleClick ? 2 : 1;
        var inputs = new NativeMethods.Input[clickPairs * 2];

        for (int i = 0; i < clickPairs; i++)
        {
            inputs[i * 2] = CreateMouseInput(down);
            inputs[i * 2 + 1] = CreateMouseInput(up);
        }

        uint sent = NativeMethods.SendInput((uint)inputs.Length, inputs, Marshal.SizeOf<NativeMethods.Input>());
        return sent == (uint)inputs.Length;
    }

    private static NativeMethods.Input CreateMouseInput(uint flags)
    {
        return new NativeMethods.Input
        {
            Type = NativeMethods.InputMouse,
            Data = new NativeMethods.InputUnion
            {
                Mouse = new NativeMethods.MouseInput
                {
                    Flags = flags,
                    ExtraInfo = UIntPtr.Zero
                }
            }
        };
    }
}
