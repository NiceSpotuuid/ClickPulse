using System.Windows;
using System.Windows.Media;
using System.Windows.Media.Animation;

namespace ClickPulse;

public partial class StatusToastWindow : Window
{
    private readonly TranslateTransform _slideTransform = new(0, 10);
    private bool _isClosing;

    public StatusToastWindow()
    {
        InitializeComponent();
        ToastRoot.RenderTransform = _slideTransform;
    }

    // The status chip remains visible while clicking is active and disappears when stopped.
    public void ShowRunning()
    {
        if (_isClosing)
            return;

        Left = SystemParameters.WorkArea.Right - Width - 18;
        Top = SystemParameters.WorkArea.Top + 18;

        BeginAnimation(OpacityProperty, null);
        if (!IsVisible)
        {
            Opacity = 0;
            _slideTransform.Y = 10;
            Show();
        }

        var easing = new CubicEase { EasingMode = EasingMode.EaseOut };
        BeginAnimation(OpacityProperty, new DoubleAnimation(0, 1, TimeSpan.FromMilliseconds(230))
        {
            EasingFunction = easing
        });
        _slideTransform.BeginAnimation(TranslateTransform.YProperty,
            new DoubleAnimation(10, 0, TimeSpan.FromMilliseconds(300)) { EasingFunction = easing });
    }

    public void HideAnimated()
    {
        if (!IsVisible || _isClosing)
            return;

        var fade = new DoubleAnimation(0, TimeSpan.FromMilliseconds(190))
        {
            EasingFunction = new QuadraticEase { EasingMode = EasingMode.EaseIn }
        };
        fade.Completed += (_, _) =>
        {
            if (!_isClosing)
            {
                Hide();
                BeginAnimation(OpacityProperty, null);
                Opacity = 0;
                _slideTransform.Y = 10;
            }
        };
        BeginAnimation(OpacityProperty, fade);
        _slideTransform.BeginAnimation(TranslateTransform.YProperty,
            new DoubleAnimation(0, -6, TimeSpan.FromMilliseconds(190))
            {
                EasingFunction = new QuadraticEase { EasingMode = EasingMode.EaseIn }
            });
    }

    public void CloseImmediately()
    {
        _isClosing = true;
        if (IsVisible)
            Close();
    }
}
