# ClickPulse

Schlichter Windows-Autoklicker als C#-WPF-Projekt für Windows 10/11.

## Oberfläche

- Normale Windows-Titelleiste mit App-Icon und den üblichen Minimieren-, Maximieren- und Schließen-Schaltflächen
- Helle, weiße Oberfläche im Stil eines normalen Windows-Desktopprogramms
- Dezente Rahmen, Standard-Steuerelemente und zurückhaltende blaue Start-Schaltfläche
- Kleine Statusmeldung oben rechts beim Start; sie wird beim Stoppen weich ausgeblendet
- Statusmeldung kann in den Einstellungen deaktiviert werden und die Auswahl wird gespeichert

## Funktionen

- Globaler Hotkey **F6** zum Starten und Stoppen
- Intervall in Stunden, Minuten, Sekunden und Millisekunden
- Optionale zufällige Intervall-Abweichung
- Linke, rechte oder mittlere Maustaste
- Einzel- oder Doppelklick
- Wiederholung bis zum Stoppen oder mit fester Anzahl
- Aktuelle Mausposition oder feste Bildschirmkoordinaten
- Bildschirmposition mit der Schaltfläche **Position wählen** festlegen
- **ESC** stoppt den Autoklicker, wenn ClickPulse fokussiert ist

## Voraussetzungen

- Windows 10 oder Windows 11, 64-bit
- .NET 8 SDK oder Visual Studio 2022 mit der Workload **.NET-Desktopentwicklung**

## Mit Visual Studio starten

1. ZIP-Datei entpacken.
2. `ClickPulse.sln` in Visual Studio 2022 öffnen.
3. Oben die Konfiguration **Release** auswählen.
4. **Erstellen → Projektmappe erstellen** auswählen.
5. Zum Starten **F5** drücken.

## Eigenständige EXE erstellen

Die eigenständige EXE enthält die .NET-Laufzeit und kann auch auf Windows-PCs ohne separat installiertes .NET 8 ausgeführt werden.

1. .NET 8 SDK installieren.
2. `publish-win-x64.bat` im Projektordner doppelklicken.
3. Die fertige Anwendung liegt hier:

```text
bin\Release\net8.0-windows\win-x64\publish\ClickPulse.exe
```

Alternativ in PowerShell im Projektordner:

```powershell
dotnet restore
dotnet publish ClickPulse.csproj -c Release -p:PublishProfile=win-x64.pubxml
```

Die EXE wird größer als eine frameworkabhängige Build-Datei sein, da die Laufzeit eingebunden ist.

## Bedienung

- **F6**: Starten / Stoppen
- **ESC**: Stoppen (wenn ClickPulse fokussiert ist)
- **Position wählen**: Danach einmal auf die gewünschte Bildschirmposition klicken
- **Statusmeldung oben rechts anzeigen**: Desktop-Meldung ein- oder ausschalten

Die Einstellung der Statusmeldung wird unter `%AppData%\ClickPulse\settings.json` gespeichert. Fehlerdetails stehen bei Bedarf unter `%AppData%\ClickPulse\error.log`.

Das Klickintervall ist auf mindestens 10 ms begrenzt. Verwende automatisierte Eingaben nur in Anwendungen, in denen sie erlaubt sind.
